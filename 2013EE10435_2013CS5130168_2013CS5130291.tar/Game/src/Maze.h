#ifndef MAZE_H_
#define MAZE_H_

#include "Structures.h"

void initialize ( grid** maze, int num );
void prims ( grid** maze, int num );

#endif