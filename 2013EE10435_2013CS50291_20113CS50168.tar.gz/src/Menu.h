#ifndef MENU_H_
#define MENU_H_

//#include <GL/glui.h>

void create_menu ( GLUI *glui );
void zoom_func ( int i );
void increase_vel ( int i );
void decrease_vel ( int i );
void stop_vel ( int i );
void deselect ( int i );
void change_view ( int j );
void exit_func ( int i );
void screen_saver ( int i );

#endif
